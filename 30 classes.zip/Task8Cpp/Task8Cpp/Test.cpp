#include "Test.h"
#include<math.h>

double Test::Task8(double& y)
{
	return   sqrt(fabs(6 * pow(y, 2) - 0.1 * y + 4));
};
