#pragma once
class Test
{
public:
	double Task27(double& y, double& x, double& v);
};

