#pragma once
class Test
{
public:
	double Task19(double& y, double& n, double& g);
};

