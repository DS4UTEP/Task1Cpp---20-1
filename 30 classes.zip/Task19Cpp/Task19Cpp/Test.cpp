#include "Test.h"
#include <math.h>

double Test::Task19(double& y, double& n, double& g)
{
	return n * sqrt(pow(y, 3) + 1.09 * g);
}