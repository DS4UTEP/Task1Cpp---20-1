#include "Test.h"
#include <math.h>

double Test::Task13(double &y)
{
    return sqrt(fabs(3 * pow(y, 2) + 0.5 * y + 4));
}