#pragma once
class Test
{
public:
	double Task13(double &y);
};
