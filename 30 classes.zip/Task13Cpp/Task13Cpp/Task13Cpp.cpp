﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double y;
        cout << "Введите значение переменных y" << endl;
        cin >> y;
        cout << "Задание13 = " << t.Task13(y) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}