#include "Test.h"
#include <math.h>

double Test::Task24(double& y)
{
	return 2 * sin(0.214 * pow(y, 5) + 1);
}