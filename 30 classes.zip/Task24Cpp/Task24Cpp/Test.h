#pragma once
class Test
{
public:
	double Task24(double& y);
};

