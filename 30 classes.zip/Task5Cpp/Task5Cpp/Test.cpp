#include "Test.h"
#include<math.h>

double Test::Task5(double& x)
{
	return   1.51 * cos(pow(x, 2)) + 2 * pow(x, 3);
};
