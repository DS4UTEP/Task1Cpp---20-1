#pragma once
class Test
{
public:
	double Task5(double& x);
};

