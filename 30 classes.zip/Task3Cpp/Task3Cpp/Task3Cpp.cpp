﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double n, y;
        cout << "Введите значение переменных n" << endl;
        cin >> n;
        cout << "Введите значение переменных y" << endl;
        cin >> y;
        cout << "Задание 3 = " << t.Task3(n, y) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}
