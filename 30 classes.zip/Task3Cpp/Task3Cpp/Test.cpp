#include "Test.h"
#include<math.h>

double Test::Task3(double& n, double& y)
{
	return   n * (y + 3.5) + sqrt(y);
};