#pragma once
class Test
{
public:
	double Task3(double& n, double& y);
};


