#include "Test.h"
#include<math.h>

double Test::Task9(double& y, double &x)
{
	return   log10(y + 0.95) + sin(pow(x, 4));
};
