﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double y, x;
        cout << "Введите значение переменных y" << endl;
        cin >> y;
        cout << "Введите значение переменных x" << endl;
        cin >> x;
        cout << "Задание9 = " << t.Task9(y, x) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}
