#pragma once
class Test
{
public:
	double Task9(double &y, double &x);
};
