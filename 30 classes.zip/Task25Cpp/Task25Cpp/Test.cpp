#include "Test.h"
#include <math.h>

double Test::Task25(double& y, double& f)
{
	return exp(y * 2) + sin(pow(f, 2));
}