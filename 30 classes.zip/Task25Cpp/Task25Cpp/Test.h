#pragma once
class Test
{
public:
	double Task25(double& y, double& f);
};
