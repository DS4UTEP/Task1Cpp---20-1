﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double p, y;
        cout << "Введите значение переменных p" << endl;
        cin >> p;
        cout << "Введите значение переменных y" << endl;
        cin >> y;
        cout << "Задание2 = " << t.Task2(p, y) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}