#pragma once
class Test
{
public:
	double Task2(double& p, double& y);
};
