#include "Test.h"
#include<math.h>

double Test::Task2(double& p, double& y)
{
	return  log10(pow(p, 2) + pow(y, 3)) + exp(p);
};