#include "Test.h"
#include <math.h>

double Test::Task14(double& y, double& x)
{
	return fabs(sqrt(pow(sin(y), 2) + 6.835) + exp(x));
}