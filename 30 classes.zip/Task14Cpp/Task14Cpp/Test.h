#pragma once
class Test
{
public:
	double Task14(double& y, double& x);
};
