#include "Test.h"
#include <math.h>

double Test::Task26(double& p)
{
	return sin(pow(pow(p, 2) + 0.4, 3));
}

