#pragma once
class Test
{
public:
	double Task26(double& p);
};

