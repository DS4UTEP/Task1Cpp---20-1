#pragma once
class Test
{
public:
    double Task12(double &t, double &x);
};

