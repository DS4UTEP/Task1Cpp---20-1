﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test d;
        double t, x;
        cout << "Введите значение переменных x" << endl;
        cin >> x;
        cout << "Введите значение переменных t" << endl;
        cin >> t;
        cout << "Задание 12 = " << d.Task12(t, x) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}
