#include "Test.h"
#include <math.h>

double Test::Task12(double &t, double &x)
{
    return 7 * pow(t, 2) + 3 * sin(pow(x, 3)) + 9.2;
}