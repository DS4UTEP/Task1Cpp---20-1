#include "Test.h"
#include<math.h>

double Test::Task10(double& k, double &y, double &x)
{
	return   exp(y) + 7.355 * pow(k, 2) + pow(sin(x), 2);
};
