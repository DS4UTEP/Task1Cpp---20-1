#pragma once
class Test
{
public:
	double Task10(double& y, double &x, double &k);
};
