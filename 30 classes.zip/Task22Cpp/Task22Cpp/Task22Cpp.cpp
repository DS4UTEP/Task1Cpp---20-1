﻿#include <iostream>
#include <math.h>
#include "Test.h"

using namespace std;

int  main()
{

	//Задание №21
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, x, u;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "Введите значение переменной u " << endl;
		cin >> u;
		cout << "Задание22 = " << t.Task22(y, u, x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
