#pragma once
#pragma once
class Test
{
public:
	double Task22(double& y, double& u, double& x);
};

