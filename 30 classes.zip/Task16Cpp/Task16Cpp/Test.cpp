#include "Test.h"
#include <math.h>

double Test::Task16(double& y) 
{
	return sqrt(cos(pow(4 * y, 2)) + 7.151);
}