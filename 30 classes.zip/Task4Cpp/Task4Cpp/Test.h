#pragma once
class Test
{
public:
	double Task4(double& a, double& t);
};

