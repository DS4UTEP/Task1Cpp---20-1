#include "Test.h"
#include<math.h>

double Test::Task4(double& a, double& t)
{
	return   9.8 * pow(a, 2) + 5.52 * cos(pow(t, 5));
};
