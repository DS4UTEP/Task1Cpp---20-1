﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test d;
        double a, t;
        cout << "Введите значение переменных a" << endl;
        cin >> a;
        cout << "Введите значение переменных t" << endl;
        cin >> t;
        cout << "Задание4 = " << d.Task4(a, t) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}
