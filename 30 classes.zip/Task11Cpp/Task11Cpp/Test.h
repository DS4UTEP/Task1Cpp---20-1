#pragma once
class Test
{
public:
	double Task11(double& y, double& x);
};
