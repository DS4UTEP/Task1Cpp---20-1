#include "Test.h"
#include <math.h>

double Test::Task11(double& y, double& x)
{
	return 9.756 * pow(y, 7) + 2 * tan(x);
}
