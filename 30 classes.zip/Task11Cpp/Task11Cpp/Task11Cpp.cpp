﻿#include <iostream>
#include <math.h>
#include "Test.h"

using namespace std;

int  main()
{

	//Задание №11
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "Задание11 = " << t.Task11(y, x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
