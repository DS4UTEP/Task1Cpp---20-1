#include "Test.h"
#include <math.h>

double Test::Task29(double& y)
{
	return 3 * pow(y, 2) + sqrt(fabs(y + 1));
}
