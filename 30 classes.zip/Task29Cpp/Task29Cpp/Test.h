#pragma once
class Test
{
public:
	double Task29(double& y);
};
