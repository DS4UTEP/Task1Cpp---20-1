#include "Test.h"
#include <math.h>

double Test::Task23(double& y, double& f)
{
	return exp(2 * y) + sin(f);
}
