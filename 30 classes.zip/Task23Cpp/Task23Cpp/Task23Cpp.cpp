﻿#include <iostream>
#include <math.h>
#include "Test.h"

using namespace std;

int  main()
{

	//Задание №23
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, f;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной f " << endl;
		cin >> f;
		cout << "Задание23 = " << t.Task23(y, f) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
