#pragma once
class Test
{
public:
	double Task23(double& y, double& f);
};

