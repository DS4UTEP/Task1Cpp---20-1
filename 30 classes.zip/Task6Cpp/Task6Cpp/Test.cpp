#include "Test.h"
#include<math.h>

double Test::Task6(double& x, double& y)
{
	return   cos(2 * y) + 3.6 * exp(x);
};
