#pragma once
class Test
{
public:
	double Task6(double& x, double& y);
};


