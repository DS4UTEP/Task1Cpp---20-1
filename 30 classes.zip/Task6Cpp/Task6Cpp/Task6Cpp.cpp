﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double y, x;
        cout << "Введите значение переменных x" << endl;
        cin >> x;
        cout << "Введите значение переменных y" << endl;
        cin >> y;
        cout << "Задание 6 = " << t.Task6(x, y) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}