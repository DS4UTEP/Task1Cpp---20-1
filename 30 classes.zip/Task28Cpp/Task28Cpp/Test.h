#pragma once
class Test
{
public:
	double Task28(double& y, double& h);
};

