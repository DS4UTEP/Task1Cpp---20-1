#pragma once
class Test
{
public:
	double Task17(double& y);
};

