#include "Test.h"
#include <math.h>

double Test::Task17(double& y)
{
	return 3 * pow(y, 2) + sqrt(y + 1);
}
