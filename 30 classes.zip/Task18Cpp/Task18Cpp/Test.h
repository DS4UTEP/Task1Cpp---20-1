#pragma once
class Test
{
public:
	double Task18(double& y);
};

