#include "Test.h"
#include <math.h>

double Test::Task18(double& y)
{
	return 3 * pow(y, 2) + sqrt(pow(y, 2) + 1);
}