﻿#include <iostream>
#include <math.h>
#include "Test.h"

using namespace std;

int  main()
{

	//Задание №21
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, h;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной h " << endl;
		cin >> h;
		cout << "Задание 31 = " << t.Task21(y, h) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
