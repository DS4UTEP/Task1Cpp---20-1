#include "Test.h"
#include <math.h>

double Test::Task21(double& y, double& h)
{
	return exp(y + 5.5) + 9.1 * pow(h, 3);
}