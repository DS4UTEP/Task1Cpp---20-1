#pragma once
class Test
{
public:
	double Task21(double& y, double& h);
};

