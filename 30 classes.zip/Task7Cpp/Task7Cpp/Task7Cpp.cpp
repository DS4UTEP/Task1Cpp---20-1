﻿#include <iostream>
#include <cmath>
#include "Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test t;
        double m;
        cout << "Введите значение переменных m" << endl;
        cin >> m;
        cout << "Задание 7 = " << t.Task7(m) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}