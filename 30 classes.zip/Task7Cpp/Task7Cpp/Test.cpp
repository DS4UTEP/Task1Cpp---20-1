#include "Test.h"
#include<math.h>

double Test::Task7(double& m)
{
	return   pow(m, 2) + 2.8 * fabs(m) + 0.55;
};