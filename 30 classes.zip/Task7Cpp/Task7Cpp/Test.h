#pragma once
class Test
{
public:
	double Task7(double& x);
};

