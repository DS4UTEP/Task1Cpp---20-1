#include "Test.h"
#include<math.h>

double Test::Task1Cpp(double& t, double& l)
{
	return  3 * pow(t, 2) + 3 * pow(l, 5) + 4.9;
};