#pragma once
class Test
{
public:
	double Task1Cpp(double& t, double& l);
};
