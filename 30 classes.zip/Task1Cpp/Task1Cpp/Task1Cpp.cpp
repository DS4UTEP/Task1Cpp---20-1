﻿#include <iostream>
#include <cmath>
#include"Test.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");

    try
    {
        Test d;
        double t, l;
        cout << "Введите значение переменных t" << endl;
        cin >> t;
        cout << "Введите значение переменных l" << endl;
        cin >> l;
        cout << "Задание1 = " << d.Task1Cpp(t, l) << endl;

    }
    catch (const std::exception)
    {
        cout << "Ошибка входных данных" << endl;
    }

    system("pause");
}