﻿#include <iostream>
#include <math.h>
#include "Test.h"

using namespace std;

int  main()
{

	//Задание №20
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, x, k;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной k " << endl;
		cin >> k;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "Задание20 = " << t.Task20(y, k, x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
