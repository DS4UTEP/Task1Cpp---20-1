#include "Test.h"
#include <math.h>

double Test::Task20(double& y, double& k, double& x)
{
	return exp(k + y) + tan(x) * sqrt(y);
}
