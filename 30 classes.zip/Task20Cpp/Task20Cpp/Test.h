#pragma once
class Test
{
public:
	double Task20(double& y, double& k, double& x);
};

