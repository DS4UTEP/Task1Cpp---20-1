#pragma once
class Test
{
public:
	double Task30(double& y, double& r);
};

