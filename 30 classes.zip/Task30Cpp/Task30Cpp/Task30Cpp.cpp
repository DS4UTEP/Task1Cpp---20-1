﻿#include <iostream>
#include "Test.h"
#include <math.h>

using namespace std;

int  main()
{

	//Задание №30
	setlocale(LC_ALL, "Rus");

	try
	{
		Test t;
		double y, r;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной r " << endl;
		cin >> r;
		cout << "Задание30 = " << t.Task30(y, r) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
