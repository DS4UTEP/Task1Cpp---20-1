#include "Test.h"
#include <math.h>

double Test::Task30(double& y, double& r)
{
	return exp(y + r) + 7.2 * sin(r);
}