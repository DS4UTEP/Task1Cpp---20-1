#pragma once
class Test
{
public:
	double Task15(double& y);
};

