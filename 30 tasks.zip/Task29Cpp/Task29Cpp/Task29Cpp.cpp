﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №29
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, x, u;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "N = " << 3 * pow(y,2) + sqrt(abs(y+1)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
