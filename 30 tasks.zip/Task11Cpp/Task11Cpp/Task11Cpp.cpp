﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №11
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "S = " << 9.756 * pow(y,7) + 2 * tan(x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
