﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №3
	setlocale(LC_ALL, "Rus");

	try
	{
		double n, y;
		cout << "Введите значение переменной n " << endl;
		cin >> n;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "G =" << n * (y + 3.5) + sqrt(y) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
