﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №20
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, x, k;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной k " << endl;
		cin >> k;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "U = " << exp(k+y) + tan(x) * sqrt(y) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
