﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №8
	setlocale(LC_ALL, "Rus");

	try
	{
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "T =" << sqrt(abs(6 * pow(y, 2) - 0.1 * y + 4)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");
}
