﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №21
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, h;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной h " << endl;
		cin >> h;
		cout << "P = " << exp(y+5.5) + 9.1 * pow(h, 3) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
