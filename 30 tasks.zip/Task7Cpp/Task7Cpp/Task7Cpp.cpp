﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №7
	setlocale(LC_ALL, "Rus");

	try
	{
		double m;
		cout << "Введите значение переменной m " << endl;
		cin >> m;
		cout << "N = " << pow(m, 2) + 2.8 * abs(m) + 0.55 << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");
}
