﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №6
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "M =" << cos(2 * y) + 3.6 * exp(x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");
}
