﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №2
	setlocale(LC_ALL, "Rus");

	try
	{
		double p, y;
		cout << "Введите значение переменной p " << endl;
		cin >> p;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "K = " << log10(pow(p, 2) + pow(y, 3) + exp(p)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
