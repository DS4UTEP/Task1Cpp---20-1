﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №25
	setlocale(LC_ALL, "Rus");

	try
	{
		double y, f;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной f " << endl;
		cin >> f;
		cout << "G = " << exp(y * 2) + sin(pow(f, 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

}
