﻿#include <iostream>
#include <cmath>

using namespace std;

int  main()
{

	//Задание №4
	setlocale(LC_ALL, "Rus");

	try
	{
		double a, t;
		cout << "Введите значение переменной a " << endl;
		cin >> a;
		cout << "Введите значение переменной t " << endl;
		cin >> t;
		cout << "D =" << 9.8 * pow(a, 2) + 5.52 * pow(cos(t), 5) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");
}
