﻿#include <iostream>
using namespace std;

enum Auto {s_1l = 1, zaz965, raf977, s3d, zis110 = 0 };
Auto operator+(const Auto& m, const int& b)
{
    Auto a = Auto(b + m);

    return(a = Auto(a % 5));
}

Auto operator+(const int& b, const Auto& m)
{
    return (m + b);
}
Auto operator++(Auto& m)
{
    return (m = Auto(m + 1));
}
Auto operator++(Auto& m, int)
{
    Auto a = m; m = Auto(m + 1);
    return a;
}
void print(const Auto& d)
{
    string Autos[5] =
    {
        "С-1Л","ЗАЗ-965","РАФ-977","С-3Д","ЗИС-110"
    };
    cout << Autos[d] << endl;
};

int main()
{
    setlocale(LC_ALL, "Rus");


    Auto m = s3d;
    print(m + 1);
    print(2 + m);
    print(operator+(m, 1));
    print(operator+(2, m));
    m++;
    print(m);
    print(++m);
    print(operator++(m));
    print(operator++(m, 0));
    print(m);

    system("pause");
}